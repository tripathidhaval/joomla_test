<?php  
defined('_JEXEC') or die('Restricted Area'); 

$user = JFactory::getUser();
// DO NOT Display message if user is guest
if($user->guest){
    echo JText::_('MOD_WELCOME_MESSAGE_LOGIN_FIRST');
}else{
    $date = new DateTime($user->lastvisitDate, new DateTimeZone('Asia/Kolkata'));    
    echo JText::sprintf('MOD_WELCOME_MESSAGE_TEXT', $user->name, $date->format('jS F Y H:i A'));    
}

	